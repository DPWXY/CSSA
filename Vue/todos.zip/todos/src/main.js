import { createApp } from 'vue'
import App from './App.vue'
import './index.less'
import "./assets/css/bootstrap.css"

createApp(App).mount('#app')
