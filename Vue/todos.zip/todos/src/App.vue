<template>
  <h1>App 根组件</h1>
  <!--TODO 使用v-on接收todo-input的自定义事件，并用onAddNewTask方法来处理-->
  <todo-input @taskName="onAddNewTask"/>
  <!--TODO 把todoList换成计算属性taskList-->
  <todo-list :list="taskList" class="mt-2"/>
  <todo-button v-model:active="activeBtnIndex"/>
  <h1>{{activeBtnIndex}}</h1>
</template>

<script>
export default {
  name: 'App',
}
</script>

<script setup>
import TodoList from "./components/todo-list/todo-list.vue"
import TodoInput from "./components/todo-input/todo-input.vue"
import TodoButton from "./components/todo-button/todo-button.vue";
import {computed} from "vue";

const todoList = $ref([
  {id: 1, task: "周一早晨9点开会", done: false},
  {id: 2, task: "周一晚上8点聚餐", done: false},
  {id: 3, task: "准备周三上午的演讲稿", done: true}
])
const updatedList =$ref()
// TODO 把新的任务加到任务列表中
function onAddNewTask(taskName) {
  let new_id = todoList[todoList.length-1].id +1
todoList.push({id:new_id, task:taskName, done:false})
}

let activeBtnIndex = $ref(1)

// TODO 根据activeBtnIndex的值，过滤todoList并显示在页面上
const taskList = computed(() => {
  switch (activeBtnIndex) {
    case 0:
      return todoList// TODO
    case 1:
      // return computed(()=>todoList.reduce((pre, cur)=>cur.done===true))// TODO
         console.log("button 1")
          let list = []
          for (let i = 0;i<todoList.length; i++){
            let item = todoList[i]
            if (item.done === true){

              list.push(item)
               console.log(item)
            }

          }
          console.log(list)
          return list
    case 2:
              console.log("button 1")
          let list1 = []
          for (let i = 0;i<todoList.length; i++){
            let item = todoList[i]
            if (item.done === false){

              list1.push(item)
               console.log(item)
            }

          }
          console.log(list1)
          return list1
  }
})

</script>

<style lang="less" scoped>

</style>